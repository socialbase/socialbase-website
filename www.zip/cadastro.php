<?php

  require( 'functions.php' );

  get_template_part( 'register/header' );

  get_template_part( 'register/register' );

  get_template_part( 'register/footer' );

?>
