<section class="wrapper mobile">
  <div class="container">
    <div class="row">

      <div class="col-md-10 offset-md-1">
        <p class="subtitle">Versões Web/Mobile</p>
        <h2>Para ser comunicação, <br class="d-none d-md-block" /> não pode haver limitações.</h2>
        <p>Não importa de onde, não importa quando. <br class="d-none d-md-block" /> Do navegador ou do celular, comunique-se <br class="d-none d-lg-block" /> sempre.</p>
      </div>

    </div>
  </div>
</section>
