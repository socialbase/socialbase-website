<?php
 if ( $_POST ) {
   echo 'success';
 }
?>
