<section class="wrapper culture" style="display:none;">
  <div class="container-fluid">
    <div class="row">

      <div class="col-12 text-center">
        <h2>Nossa <span class="hashtag">#cooltura</span></h2>
      </div>

      <div class="col-12 p-md-0 mt-4 culture-slider slick-slider"></div>

    </div>
  </div>
</section>
