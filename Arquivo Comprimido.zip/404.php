<?php

  require( 'functions.php' );

  get_header();

  get_template_part( 'global/404' );

  get_footer();

?>
