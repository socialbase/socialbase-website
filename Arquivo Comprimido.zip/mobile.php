<?php
  require( 'functions.php' );

  get_template_part( 'login/header' );

  get_template_part( 'mobile/mobile-body' );

  get_template_part( 'login/footer' );
?>