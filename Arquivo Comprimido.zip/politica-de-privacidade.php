<?php

  require( 'functions.php' );

  get_header();

  get_template_part( 'policy/policy' );

  get_footer();

?>
