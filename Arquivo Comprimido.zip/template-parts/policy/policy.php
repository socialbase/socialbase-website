<section class="wrapper policy">
  <div class="container">
    <div class="row">

      <div class="col-md-7 order-md-2">
        <?php include( 'article.php' ); ?>
      </div>

      <div class="col-md-5 order-md-1">
        <?php include( 'sidebar.php' ); ?>
      </div>

    </div>
  </div>
</section>
