<style>
  .policy-title {
    color: #9D81EB !important;
  }
</style>

<aside id="sidebar" class="sticky-top">
  <a class="policy-title" href="#politica-de-privacidade" rel="nofollow"><strong>Política de Privacidade</strong></a>
  <a href="#tratamento-de-dados" class="list-group-item" rel="nofollow">Tratamento de dados</a>
  <a href="#uso-da-rede-social" class="list-group-item" rel="nofollow">Informações referentes ao uso da Rede Social</a>
  <a href="#acesso-website" class="list-group-item" rel="nofollow">Informações referentes ao acesso do website</a>
  <a href="#informacoes-de-terceiros" class="list-group-item" rel="nofollow">Compartilhando Informações com Terceiros</a>
  <a href="#estatistica-empregada" class="list-group-item" rel="nofollow">Estatística Agregada</a>
  <a href="#divulgacao-obrigatoria" class="list-group-item" rel="nofollow">Divulgação Legalmente Obrigatória</a>
  <a href="#dados-pessoais" class="list-group-item" rel="nofollow">Processamento de Dados Pessoais</a>
  <a href="#informacoes-de-seguranca" class="list-group-item" rel="nofollow">Informações gerais a respeito de segurança</a>
  <a href="#informacoes-desta-politica" class="list-group-item" rel="nofollow">Informações gerais a respeito desta política</a>
</aside>
