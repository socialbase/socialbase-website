    </main>

    <script>
    /* <![CDATA[ */
    var assets = {'uri':'<?= ASSETS_URI; ?>'};
    var site = {'url':'<?= SITE_URL; ?>','domain':'<?= $_SERVER['SERVER_NAME'] ?>'};
    /* ]]> */
    </script>
    <script src="<?= ASSETS_URI; ?>/plugins/jquery/jquery-3.5.1.min.js?v=<?= VERSION; ?>"></script>
    <script src="<?= ASSETS_URI; ?>/plugins/bootstrap-4.5.2/js/bootstrap.min.js?v=<?= VERSION; ?>"></script>
    <script src="<?= ASSETS_URI; ?>/plugins/jquery/jquery.validate.min.js?v=<?= VERSION; ?>"></script>
    <script src="<?= ASSETS_URI; ?>/layout/js/login.js?v=<?= VERSION; ?>"></script>

  </body>
</html>
