<section class="wrapper notfound">
  <div class="container">
    <div class="row">

      <div class="col-md-6 offset-md-3 text-center">
        <img src="<?= ASSETS_IMAGES_URI; ?>/bgs/socialbase-bg-404.png" class="img-fluid mb-20" alt="404" />
        <p>Xiii... Parece que tivemos um ruído na nossa comunicação. <br /> A página que você tentou acessar não foi encontrada. <br class="d-none d-sm-block" /> Mas não vamos deixar nossa conversa acabar por aqui!</p>
        <a href="<?= SITE_URL; ?>" class="btn btn-blue mt-20">Voltar para o site</a>
      </div>

    </div>
  </div>
</section>
