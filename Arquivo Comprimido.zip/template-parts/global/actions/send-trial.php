<?php
 if ( $_POST ) {
   //print_r( $_POST );
   echo 'success';
 }
?>
