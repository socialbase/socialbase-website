<header class="header">
  <nav class="navbar navbar-expand-lg">
    <div class="container">
      <a href="<?= SITE_URL; ?>" class="navbar-brand"><img src="<?= ASSETS_IMAGES_URI; ?>/logos/socialbase-logo.svg" alt="SocialBase" /></a>
      <a href="https://login.socialbase.com.br" class="btn btn-blue btn-sm" rel="nofollow">Entrar</a>
    </div>
  </nav>
</header>
