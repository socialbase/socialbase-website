<section class="register">
  <div class="container">
    <div class="row d-flex align-items-end">

      <?php
        get_template_part( 'register/testimonial' );
        get_template_part( 'register/form' );
      ?>

    </div>
  </div>
</section>
