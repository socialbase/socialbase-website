<?php

  require( 'functions.php' );

  get_template_part( 'login/header' );

  get_template_part( 'login/login' );

  get_template_part( 'login/footer' );

?>
